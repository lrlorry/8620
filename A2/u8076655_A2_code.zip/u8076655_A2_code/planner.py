"""Serial, generative-model UCT with guided action widening and rollouts.

The only simulator interfaces used here are get_config(), simulate(), and
num_actions (property in the supplied implementation; methods also work).
"""

from collections import deque
from dataclasses import dataclass, field
from itertools import product
import math
import time

import numpy as np
from scipy.ndimage import distance_transform_edt


def action_vectors(change_altitude):
    return np.asarray([v for v in product((-1, 0, 1), repeat=3)
                       if any(v) and (change_altitude or v[2] == 0)], dtype=np.int32)


def encode_action(digits, base):
    value, multiplier = 0, 1
    for digit in digits:
        value += int(digit) * multiplier
        multiplier *= base
    return value


def decode_action(value, base, count):
    if not 0 <= int(value) < base ** count:
        raise ValueError('Action is outside the joint action space')
    digits = []
    for _ in range(count):
        digits.append(int(value) % base)
        value = int(value) // base
    return digits


@dataclass(slots=True)
class Edge:
    visits: int = 0
    value: float = 0.0
    children: dict = field(default_factory=dict)


@dataclass(slots=True)
class Node:
    visits: int = 0
    actions: dict = field(default_factory=dict)


class Deadline(Exception):
    pass


class MCTSPlanner:
    def __init__(self, env, seed=0, tree_depth=8, rollout_depth=8,
                 exploration=0.35, widening=1.5, random_action_prob=0.15,
                 rollout_epsilon=0.10, max_simulations=2000,
                 guided=True, leaf_heuristic=True, progressive=True,
                 max_map_cells=150000):
        self.env = env
        self.cfg = env.get_config()
        self.goals = np.asarray(self.cfg.goal_positions, dtype=np.int32)
        self.count = len(self.goals)
        self.shape = tuple(self.cfg.grid_size)
        self.physical_vectors = action_vectors(self.cfg.change_altitude)
        # Optional action masks are used ONLY in controlled experiments.
        allowed = getattr(self.cfg, 'intended_action_indices', None)
        self.vectors = self.physical_vectors if allowed is None else self.physical_vectors[allowed]
        self.base = len(self.vectors)
        advertised = env.num_actions
        self.action_count = int(advertised() if callable(advertised) else advertised)
        if self.action_count != self.base ** self.count:
            raise ValueError('Action count does not match the documented per-drone encoding')
        if min(tree_depth, rollout_depth, max_simulations) < 0:
            raise ValueError('Depth and simulation limits must be nonnegative')
        self.tree_depth, self.rollout_depth = int(tree_depth), int(rollout_depth)
        self.exploration, self.widening = float(exploration), float(widening)
        self.random_action_prob = float(random_action_prob)
        self.rollout_epsilon = float(rollout_epsilon)
        self.max_simulations = int(max_simulations)
        self.guided, self.leaf_heuristic, self.progressive = guided, leaf_heuristic, progressive
        self.rng = np.random.default_rng(seed)
        self.gamma = float(self.cfg.discount_factor)
        self.scale = max(1., self.count * (abs(self.cfg.goal_reward) +
                                         2 * abs(self.cfg.collision_penalty)))
        self.blocked = {tuple(p) for p in (self.cfg.obstacle_cells or [])}
        self.maps = None
        self.clearance = None
        if math.prod(self.shape) <= max_map_cells:
            free = np.ones(self.shape, dtype=bool)
            for position in self.blocked:
                free[position] = False
            self.clearance = distance_transform_edt(free)
            self.maps = [self._distance_map(tuple(g), free) for g in self.goals]
        self._options_cache = {}
        self.steps = 0
        self.last_stats = {}

    def _distance_map(self, goal, free):
        distance = np.full(self.shape, -1, dtype=np.int32)
        if not free[goal]:
            return distance
        queue = deque([goal])
        distance[goal] = 0
        vectors = self.physical_vectors.tolist()
        X, Y, Z = self.shape
        while queue:
            p = queue.popleft()
            d = distance[p] + 1
            for dx, dy, dz in vectors:
                q = p[0]+dx, p[1]+dy, p[2]+dz
                if 0 <= q[0] < X and 0 <= q[1] < Y and 0 <= q[2] < Z:
                    if distance[q] < 0 and free[q]:
                        distance[q] = d
                        queue.append(q)
        return distance

    def reset(self):
        self.steps = 0
        self.last_stats = {}

    def _distance(self, i, position):
        if self.maps is None:
            delta = np.abs(np.asarray(position) - self.goals[i])
            if not self.cfg.change_altitude and delta[2]:
                return math.inf
            return float(delta.max())
        d = self.maps[i][tuple(position)]
        return float(d) if d >= 0 else math.inf

    def unreachable_drones(self, state):
        if self.maps is None:
            return []
        return [i for i in range(self.count)
                if not state[i, 3] and not math.isfinite(self._distance(i, state[i, :3]))]

    def _options(self, i, position):
        key = (i, *map(int, position))
        if key in self._options_cache:
            return self._options_cache[key]
        targets = position + self.vectors
        scores = np.full(self.base, 1e6, dtype=float)
        for j, target in enumerate(targets):
            point = tuple(map(int, target))
            if all(0 <= point[k] < self.shape[k] for k in range(3)) and point not in self.blocked:
                distance = self._distance(i, point)
                scores[j] = (distance if math.isfinite(distance) else 1e4)
                scores[j] += 0.025 * np.abs(target - self.goals[i]).sum()
                if self.clearance is not None:
                    scores[j] += 0.3 / max(1., self.clearance[point])
        result = [tuple(map(int, q)) for q in targets], scores
        self._options_cache[key] = result
        return result

    def _proposal(self, state, randomize=True):
        reached = state[:, 3].astype(bool)
        if not self.guided or (randomize and self.rng.random() < self.random_action_prob):
            digits = self.rng.integers(self.base, size=self.count)
            digits[reached] = 0  # Reached drones are frozen; equivalent labels collapse.
            return encode_action(digits, self.base)
        reserved = {tuple(p) for p in state[reached, :3]}
        active = np.flatnonzero(~reached)
        if randomize:
            active = self.rng.permutation(active)
        digits = np.zeros(self.count, dtype=int)
        for i in active:
            targets, cost = self._options(int(i), state[i, :3])
            cost = cost.copy()
            for j, target in enumerate(targets):
                if target in reserved:
                    cost[j] += 1e5
            order = np.argsort(cost, kind='stable')
            chosen = int(order[0])
            if randomize:
                pool = order[cost[order] <= cost[chosen] + 1.05][:4]
                if len(pool) > 1:
                    weights = np.exp(-3. * (cost[pool] - cost[chosen]))
                    chosen = int(self.rng.choice(pool, p=weights/weights.sum()))
            digits[i] = chosen
            reserved.add(targets[chosen])
        return encode_action(digits, self.base)

    def _leaf(self, state, remaining):
        if not self.leaf_heuristic or remaining <= 0:
            return 0.
        distances = [self._distance(i, state[i, :3])
                     for i in range(self.count) if not state[i, 3]]
        if not distances:
            return 0.
        horizon = min(remaining, max(distances))
        if not math.isfinite(horizon):
            horizon = remaining
        horizon = int(horizon)
        costs = horizon if self.gamma == 1 else (1 - self.gamma**horizon)/(1-self.gamma)
        value = self.cfg.step_cost * self.count * costs
        value += self.cfg.goal_reward * sum(self.gamma**(int(d)-1)
                                            for d in distances if 1 <= d <= remaining)
        return float(value) / self.scale

    def _simulate(self, state, action):
        if time.perf_counter() >= self.deadline:
            raise Deadline
        self.calls += 1
        return self.env.simulate(state, action)

    def _rollout(self, state, remaining):
        rewards = []
        terminal = False
        for _ in range(min(self.rollout_depth, remaining)):
            if time.perf_counter() >= self.deadline:
                break
            if self.rng.random() < self.rollout_epsilon:
                digits = self.rng.integers(self.base, size=self.count)
                digits[state[:, 3].astype(bool)] = 0
                action = encode_action(digits, self.base)
            else:
                action = self._proposal(state, randomize=False)
            state, reward, done, _ = self._simulate(state, action)
            rewards.append(float(reward)/self.scale)
            if done:
                terminal = True
                break
        tail = 0. if terminal else self._leaf(state, remaining-len(rewards))
        for reward in reversed(rewards):
            tail = reward + self.gamma * tail
        return tail

    def _search(self, node, state, remaining, depth):
        if remaining <= 0 or state[:, 3].all():
            return 0.
        if depth >= self.tree_depth:
            return self._rollout(state, remaining)
        if time.perf_counter() >= self.deadline:
            raise Deadline
        effective = self.base ** int(np.count_nonzero(state[:, 3] == 0))
        width = (max(1, math.ceil(self.widening * math.sqrt(node.visits+1)))
                 if self.progressive else effective)
        if len(node.actions) < min(effective, width):
            action = self._proposal(state, randomize=bool(node.actions))
            for _ in range(12):
                if action not in node.actions:
                    node.actions[action] = Edge()
                    break
                action = self._proposal(state, randomize=True)
        if not node.actions:
            action = self._proposal(state, randomize=False)
            node.actions[action] = Edge()
        unseen = [a for a, edge in node.actions.items() if edge.visits == 0]
        if unseen:
            action = unseen[0]
        else:
            log_n = math.log(node.visits + 1)
            action = max(node.actions, key=lambda a: node.actions[a].value +
                         self.exploration * math.sqrt(log_n/node.actions[a].visits))
        edge = node.actions[action]
        successor, reward, done, _ = self._simulate(state, action)
        if done:
            tail = 0.
        else:
            key = np.asarray(successor, dtype=np.int32).tobytes()
            child = edge.children.get(key)
            if child is None:
                child = Node()
                edge.children[key] = child
                self.nodes += 1
                tail = self._rollout(successor, remaining-1)
            else:
                tail = self._search(child, successor, remaining-1, depth+1)
        value = float(reward)/self.scale + self.gamma * tail
        edge.visits += 1
        edge.value += (value - edge.value)/edge.visits
        node.visits += 1
        return value

    def plan(self, current_state, planning_time_per_step=9.5):
        start = time.perf_counter()
        budget = float(planning_time_per_step)
        if not math.isfinite(budget) or budget < 0:
            raise ValueError('Planning budget must be finite and nonnegative')
        state = np.asarray(current_state, dtype=np.int32)
        if state.shape != (self.count, 4):
            raise ValueError('State must have one (x,y,z,reached) row per drone')
        budget = min(budget, 10.)
        self.deadline = start + max(0., 0.97 * budget - 0.002)
        self.calls, self.nodes = 0, 1
        if len(self._options_cache) > 50000:
            self._options_cache.clear()
        fallback = self._proposal(state, randomize=False)
        root = Node()
        remaining = max(0, int(self.cfg.max_num_steps) - self.steps)
        completed = 0
        try:
            while (completed < self.max_simulations and remaining > 0
                   and not state[:, 3].all() and time.perf_counter() < self.deadline):
                self._search(root, state, remaining, 0)
                completed += 1
        except Deadline:
            pass
        visited = [a for a, edge in root.actions.items() if edge.visits]
        action = max(visited, key=lambda a: (root.actions[a].visits, root.actions[a].value)) if visited else fallback
        self.last_stats = dict(elapsed=time.perf_counter()-start, simulations=completed,
                               generative_calls=self.calls, nodes=self.nodes,
                               root_actions=len(root.actions), root_visits=root.visits,
                               action=int(action), budget=budget)
        self.steps += 1
        return int(action)
