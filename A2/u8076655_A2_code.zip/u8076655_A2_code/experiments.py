"""Serial episodes, raw CSV, and resume support; never parallelizes planning."""

import os
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name] = '1'

import argparse
import csv
import hashlib
import json
from pathlib import Path
import platform
import sys
import time

from run_u8076655 import run_episode

ROOT = Path(__file__).resolve().parent


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--suite', choices=['regression','random','factorial','ablation','budget'], required=True)
    parser.add_argument('--repetitions', type=int, default=20)
    parser.add_argument('--budget', type=float, default=.04)
    parser.add_argument('--output', required=True)
    parser.add_argument('--resume', action='store_true')
    args = parser.parse_args()
    scenarios = json.loads((ROOT/'environments/manifest.json').read_text())
    variants = ['full']
    budgets = [args.budget]
    if args.suite == 'ablation':
        scenarios = [s for s in scenarios if s['name'] in
                     ['demo_open_2d','demo_four_3d','swap_2d','narrow_passage']]
        variants = ['full','no_guidance','no_leaf','no_widening','heuristic']
    elif args.suite == 'budget':
        scenarios = [s for s in scenarios if s['name'] in ['demo_open_2d','demo_four_3d','swap_2d']]
        budgets = [.02,.1,.5]
    else:
        scenarios = [s for s in scenarios if s['suite'] == args.suite]
    target = ROOT/args.output
    target.parent.mkdir(parents=True, exist_ok=True)
    if target.exists() and not args.resume:
        raise FileExistsError(f'{target} exists; use --resume')
    seen = set()
    if target.exists():
        with target.open() as stream:
            for row in csv.DictReader(stream):
                seen.add((row['scenario'],int(row['seed']),row['variant'],float(row['planning_budget'])))
    meta = dict(python=sys.version, platform=platform.platform(), processor=platform.processor(),
                serial=True, suite=args.suite, repetitions=args.repetitions,
                planner_sha256=hashlib.sha256((ROOT/'planner.py').read_bytes()).hexdigest(),
                upstream=json.loads((ROOT/'UPSTREAM.json').read_text()))
    metadata_path = target.with_suffix('.meta.json')
    if target.exists() and metadata_path.exists():
        previous = json.loads(metadata_path.read_text())
        if previous['planner_sha256'] != meta['planner_sha256']:
            raise ValueError('The planner changed; use a new results file instead of mixing versions')
    (target.with_suffix('.meta.json')).write_text(json.dumps(meta,indent=2)+'\n')
    began = time.perf_counter()
    written = 0
    with target.open('a',newline='') as stream:
        writer = None
        for scenario in scenarios:
            for variant in variants:
                for budget in budgets:
                    for seed in range(args.repetitions):
                        key = scenario['name'],seed,variant,budget
                        if key in seen:
                            continue
                        result = run_episode(ROOT/scenario['path'], seed, budget, variant, scenario['mask'])
                        if seed == 0:
                            trace_dir = target.parent/'trajectories'
                            trace_dir.mkdir(exist_ok=True)
                            trace = trace_dir/f'{args.suite}_{scenario["name"]}_{variant}_{budget}.json'
                            trace.write_text(json.dumps(result,indent=2)+'\n')
                        row = {k:v for k,v in result.items() if k not in ('trajectory','searches','final_state','config')}
                        row.update(scenario=scenario['name'], suite=args.suite,
                                   S=scenario.get('S',''), A=scenario.get('A',''), C=scenario.get('C',''),
                                   positional_state_bound=scenario.get('positional_state_bound',''),
                                   penalized_steps=result['steps'] if result['success'] else
                                   (60 if scenario['suite'] in ('factorial','random') else
                                    __import__('yaml').safe_load((ROOT/scenario['path']).read_text())['max_num_steps']))
                        if writer is None:
                            writer = csv.DictWriter(stream, fieldnames=list(row))
                            if stream.tell() == 0:
                                writer.writeheader()
                        writer.writerow(row)
                        stream.flush()
                        written += 1
                    print(f'{scenario["name"]} {variant} budget={budget}: done; new episodes={written}; elapsed={time.perf_counter()-began:.1f}s', flush=True)


if __name__ == '__main__':
    main()
