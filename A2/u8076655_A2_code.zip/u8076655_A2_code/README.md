# COMP8620 Assignment 2 — serial online multi-drone MCTS

The submission entry point is `run_u8076655.py`. It accepts the teacher's YAML
without source edits and supports the original 8/26-direction, little-endian
joint-action encoding. No trained model or network service is used.

```bash
python run_u8076655.py --config <teacher_scenario.yaml>
python run_u8076655.py --config environments/demo_open_2d.yaml
python run_u8076655.py --config environments/demo_four_3d.yaml
```

The default allowance is **9.5 seconds per decision**, at most 2,000 MCTS
trials. The loop replans after every executed transition. The deadline uses
a margin; terminal/zero-budget calls return a valid fallback without search.
Planning is serial. Numerical-library thread limits are set to one by the
runner. A planning simulator and a separate execution simulator prevent search
samples from advancing the execution RNG.
The default seed is the YAML's `seed`, or 0 if absent; `--seed` explicitly
overrides it.

```bash
python run_u8076655.py --config environments/demo_four_3d.yaml \
  --planning-time 0.5 --seed 0 --output results/demo_trace.json
```

Run headless by default. `--visualize` optionally uses the supplied Vedo
viewer; install `vedo`/`vtk` for that option. The viewer is not needed for the
solver or the marking command. Headless dependencies are NumPy, SciPy and
PyYAML; Matplotlib is needed to regenerate report plots:

```bash
python -m pip install -r requirements.txt
```

Python 3.10 or later is required. The development machine used
`/opt/miniconda3/bin/python` (3.12), which already
had these dependencies. Use your lab's Python environment with these packages.

## Solver and simulator fidelity

`planner.py` implements UCT, action progressive widening, epsilon-greedy
guided rollouts, finite-horizon truncation, and incremental Monte Carlo
backups. The first action is always available as a geometry-guided fallback.
Static goal-distance maps guide proposals and estimate leaves; every sampled
transition and reward comes from `simulate`.

The planner only accesses `get_config()`, `simulate(state, action)`, and
`num_actions` (supports a property or method). Its heuristic uses the public
configuration; it does not read the simulator's private action vectors,
distance field, RNG, live positions or time counter.

`multi_drone.py` and `multi_drone_config.py` are vendored from the teacher's
checkout, revision recorded in `UPSTREAM.json`. Only Vedo imports were moved
inside plotting functions to permit headless execution. All core methods have
identical ASTs; see `results/model_verification.json`. The original checkout
at `~/github/MultiDroneUnc` was not edited.

Important model details preserved:

- Out-of-grid directions are discarded and probabilities renormalised;
  they do not produce a boundary stay action.
- Slips may hit obstacle cells and terminate the episode.
- Reached drones remain solid and frozen; their goal rewards are paid once.
- Step cost is multiplied by the total number of drones, including reached
  ones. Shared-cell penalties count all drones involved.
- Cell swaps and diagonal segment crossings are permitted by the teacher's
  endpoint-cell collision definition.
- `simulate` does not enforce the real execution's step counter. Search tracks
  the remaining horizon itself and stops after any terminal outcome.
- Positive `alpha` is required by the supplied model. Inputs with `alpha=0`
  are rejected rather than silently changing its float32 probability rules.

The intended-command masks used in action-size experiments retain the
original physical transition model. In particular, restricting to six axial
commands does **not** remove diagonal slip outcomes or renormalise their law.
The normal demo uses the full action set.

## Verification and scenario coverage

```bash
python -m unittest discover -s tests -v
python scripts/verify_small_model.py
```

Tests cover encoding, probability rows, boundaries, obstacle and shared-cell
collisions, allowed swaps, one-time goal rewards, frozen goals, simulator
side effects, API restrictions, seeded reproducibility, independent RNGs,
discount endpoints, zero/tiny budgets, finite horizons, static infeasibility,
invalid configurations, and a known optimal terminal bandit.

The small-model verifier exhausts every positive-probability outcome of every
action at every admissible nonterminal state of a free two-drone `2x2x1`
model. This finite check complements the larger stochastic tests; it does not
claim to exhaust arbitrary grids and obstacle configurations.

`environments/manifest.json` lists **61 scenarios**:

- 18 named regression cases, including one/four-drone demo cases, already
  solved starts, partially reached goals, thin grids, reversals, swaps, narrow
  passages, altitude detours, strong wind, impossible goals and timeouts.
- 27 factorial conditions: three grid heights, three intended-action sets,
  and three nested clutter levels.
- 16 seeded generated layouts with 1–4 drones and 0–5 obstacle cells.

Statically disconnected goals and shared absorbing goals return an explicit
infeasible result. Invalid starts, bounds, obstacle placement, horizon and
noise parameters raise clear input errors. Stochastic collisions and timeouts
remain failures in the results. No finite test suite guarantees success on
every unseen instance or every wind realization.

## Reproduce experiments and figures

```bash
python scripts/make_scenarios.py
python scripts/run_all_experiments.py
python scripts/analyse_results.py
```

The full serial design executes 1,550 episodes: 360 regression, 160 generated
layout, 540 factorial, 400 ablation, and 90 planning-budget runs. Outputs are
resumable; a changed planner hash requires a new output CSV. For example:

```bash
python experiments.py --suite factorial --repetitions 20 --budget 0.04 \
  --output results/factorial.csv --resume
```

All seeds, raw outcomes, actual decision times, rewards and search counters are
in `results/*.csv`, with provenance in `*.meta.json`. Seed-0 trajectories are
retained in `results/trajectories/`. `summary.csv` gives continuous-metric
means and 95% Student-t intervals and success-rate Wilson intervals. Factorial
marginals/effects and ablation effects use paired seed blocks.

The failure-sensitive completion metric is `steps` on success and the episode
step limit on failure. It prevents a quick collision from being counted as a
fast completion. Setup time is measured separately; it includes the two
simulators and static heuristic maps. Wall-clock stopping can produce
different search trees even with the same seed; fixed-trial tests provide a
deterministic reproduction mode.

Report sources are in the sibling `A2/` folder in the workspace and in the
`report/` folder inside the submission archive. The packaged submission also
includes the complete prompt log, analysis scripts, measured raw data,
generated report figures and the scenario generator. Optional visualisation
is separate from the verified headless planning path.

To refresh measured release tables, compile and package the submission:

```bash
python scripts/finish_report.py
# In the report directory:
latexmk -pdf -interaction=nonstopmode -halt-on-error u8076655_A2_report.tex
# Back in the code directory:
python scripts/package_submission.py
# In the development workspace:
python scripts/check_package.py ../A2/u8076655_A2_code.zip
# If repackaging from an extracted archive, use instead:
python scripts/check_package.py report/u8076655_A2_code.zip
```

`check_package.py` verifies all file hashes, extracts into a temporary folder,
runs the actual entry point and unit tests there, regenerates analyses, and
recompiles the packaged report. It clears `PYTHONPATH` for these checks.
