"""Final serial checks, default-budget demos, and a forced ten-second plan."""

import os
for name in ('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS','NUMEXPR_NUM_THREADS'):
    os.environ[name]='1'

import json
from pathlib import Path
import re
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
from environment import HeadlessMultiDroneUnc
from planner import MCTSPlanner
from run_u8076655 import run_episode


def main():
    with (ROOT/'results/unit_tests.log').open('w') as stream:
        subprocess.run([sys.executable,'-m','unittest','discover','-s','tests','-v'],
                       cwd=ROOT,stdout=stream,stderr=subprocess.STDOUT,check=True)
    for script in ('verify_upstream.py','verify_small_model.py'):
        subprocess.run([sys.executable,str(ROOT/'scripts'/script)],cwd=ROOT,check=True)
    demos={}
    for name in ('demo_open_2d','demo_four_3d'):
        result=run_episode(ROOT/f'environments/{name}.yaml',seed=0,planning_time=9.5)
        (ROOT/f'results/{name}_default.json').write_text(json.dumps(result,indent=2)+'\n')
        demos[name]={k:v for k,v in result.items() if k not in ('trajectory','searches','final_state')}
        print(name,demos[name],flush=True)
        if result['max_plan_seconds']>10:
            raise AssertionError('A default-budget decision exceeded ten seconds')
    env=HeadlessMultiDroneUnc(ROOT/'environments/demo_four_3d.yaml',seed=8620)
    state=env.reset()
    planner=MCTSPlanner(env,max_simulations=100000)
    start=time.perf_counter();action=planner.plan(state,10.);elapsed=time.perf_counter()-start
    assert 0 <= action < 26**4
    if elapsed>10:raise AssertionError('The forced deadline check exceeded ten seconds')
    count=int(re.search(r'Ran (\d+) tests', (ROOT/'results/unit_tests.log').read_text()).group(1))
    result=dict(default_demos=demos,forced_10s_check={**planner.last_stats,'measured_elapsed':elapsed},
                unit_tests=count)
    (ROOT/'results/release_validation.json').write_text(json.dumps(result,indent=2)+'\n')
    print(json.dumps(result,indent=2),flush=True)


if __name__=='__main__':main()
