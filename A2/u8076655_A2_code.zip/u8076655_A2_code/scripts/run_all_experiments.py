"""Run all benchmark suites sequentially with resumable raw outputs."""

from pathlib import Path
import subprocess
import sys

ROOT=Path(__file__).resolve().parents[1]

if __name__ == '__main__':
    suites=[('regression',20,.04),('random',10,.04),('factorial',20,.04),
            ('ablation',20,.04),('budget',10,.04)]
    for suite,repetitions,budget in suites:
        subprocess.run([sys.executable,str(ROOT/'experiments.py'),'--suite',suite,
                        '--repetitions',str(repetitions),'--budget',str(budget),
                        '--output',f'results/{suite}.csv','--resume'],cwd=ROOT,check=True)
