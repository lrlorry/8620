"""Insert verified release measurements and connect the completed report sources."""

import json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
REPORT=next((p for p in (ROOT/'report',ROOT.parent/'A2')
             if (p/'u8076655_A2_report.tex').exists()),ROOT/'report')


def main():
    measured=json.loads((ROOT/'results/release_validation.json').read_text())
    small=json.loads((ROOT/'results/small_model_verification.json').read_text())
    summary=json.loads((ROOT/'results/summary.json').read_text())
    software=json.loads((ROOT/'results/software_environment.json').read_text())
    assert summary['total_episodes']==1550 and small['passed']
    rows=[]
    for name,label in [('demo_open_2d','Open 2D'),('demo_four_3d','Four 3D, five obstacles')]:
        r=measured['default_demos'][name]
        rows.append(f"{label} & {r['seed']} & {r['termination']} & {r['steps']} & {r['max_plan_seconds']:.3f}"+r' \\')
    text=(f"The {measured['unit_tests']} unit tests pass. A separate exhaustive check of the free\n"
          f"$2\\times2\\times1$ two-drone model covers {small['joint_states']} admissible nonterminal\n"
          f"joint states, {small['state_action_pairs']} state--action pairs and all\n"
          f"{small['positive_probability_outcomes']:,} positive-probability outcomes. This is exhaustive only\n"
          "for that small model. The named demo cases complete in the following\n"
          "single seed-0 checks using the default 9.5-second allowance.\n\n"
          "\\begin{table}[H]\n\\centering\\small\n"
          "\\begin{tabular}{@{}lrlrr@{}}\n\\toprule\n"
          "Task & Seed & Status & Steps & Max decision (s) \\\\\n\\midrule\n"+
          '\n'.join(rows)+"\n\\bottomrule\n\\end{tabular}\n\\end{table}\n"
          f"A forced 10-second call, with the trial cap raised to 100,000, returns\n"
          f"in {measured['forced_10s_check']['measured_elapsed']:.3f} seconds. These measured checks\n"
          "support the timing claim on this machine; they are not a hard real-time\n"
          "guarantee or evidence of success on every unseen layout.\n")
    (REPORT/'tables/validation_summary.tex').write_text(text)
    architecture=software['architecture'].replace('_',r'\_')
    environment=(f"Experiments ran serially on {software['os']} (\\texttt{{{architecture}}}), using\n"
                 f"Python {software['python']}, NumPy {software['numpy']}, SciPy {software['scipy']},\n"
                 f"and PyYAML {software['pyyaml']}. No GPU, multiprocessing or threaded planning\n"
                 "was used. Setup is timed separately from online decisions.\n")
    (REPORT/'tables/experiment_environment.tex').write_text(environment)
    main_path=REPORT/'u8076655_A2_report.tex'
    document=main_path.read_text()
    if r'\input{partB.tex}' in document:
        print('Refreshed verified measurement tables; preserved existing report prose.')
        return
    if r'\input{partB.tex}' not in document:
        (ROOT/'provenance/report_before_partB.tex').write_text(document)
        start=document.index(r'\section*{Part B: Multi-drone Planning under Uncertainty (35 points)}')
        end=document.index('\\clearpage\n\\appendix',start)
        document=document[:start]+'\\input{partB.tex}\n\n'+document[end:]
    start=document.index('OpenAI Codex was used')
    end=document.index('% =============================================================================\n% Part A',start)
    document=document[:start]+'''OpenAI Codex was used to prepare the report template, review and revise
the Part A answers, implement the Part B solver and tests, design and run
the experiments, analyse their measured results, and prepare report text,
pseudocode and figures. The supplied simulator's transition and reward
methods were preserved; their use and the headless import changes are
documented in Part B. Original-language prompts from these interactions,
including supplied draft answers, are recorded in \\texttt{AI\\_prompts.txt}
in the submitted source archive.

'''+document[end:]
    start=document.index(r'\appendix')
    document=document[:start]+r'''\appendix
\section{Prompt log and source inventory}
\label{app:ai-prompts}
\noindent The archive's top-level folder is \texttt{u8076655\_A2\_code}.

\noindent The file \texttt{AI\_prompts.txt} records the original-language prompts.

\begin{table}[H]
\centering\small
\begin{tabularx}{\linewidth}{@{}lX@{}}
\toprule File/folder & Purpose \\
\midrule
\texttt{run\_u8076655.py} & Demo entry point and closed-loop execution. \\
\texttt{planner.py} & Budgeted UCT, guidance, leaf values and diagnostics. \\
\texttt{environment.py} & Headless hooks, input checks and experimental action masks. \\
\texttt{multi\_drone*.py} & Supplied simulator and configuration class. \\
\texttt{tests/} & Unit tests for model semantics and planning behavior. \\
\texttt{environments/} & All 61 YAML scenarios and their design manifest. \\
\texttt{results/} & Raw data, provenance, verification and seed-0 traces. \\
\texttt{scripts/} & Scenario generation, serial experiments, analysis and verification. \\
\texttt{report/} & LaTeX sources, measured tables and figures. \\
\bottomrule
\end{tabularx}
\end{table}

\clearpage
\section{Regression coverage}
The 18 named scenarios each use 20 seeds and a 0.04-second allowance.
Infeasible cases and the one-step horizon case are expected failures;
stochastic collisions in feasible cases remain recorded failures.
All 16 generated layouts and the full 27-condition design are retained in
the manifest and raw data. These tests complement the 25 unit checks and
the exhaustive small-model outcome check.

\begin{table}[H]
\centering\small
\caption{Named regression scenarios. $L$ shows mean $\pm$95\% CI half-width;
its failure penalty is the scenario's own step limit.}
\begin{tabular}{@{}lcrrr@{}}
\toprule Scenario & Success & Collisions & $L$ & Max plan (s) \\
\midrule
\RegressionRows
\bottomrule
\end{tabular}
\end{table}

\clearpage
\begin{thebibliography}{9}
\bibitem{mdp-lectures}
H. Kurniawati, \textit{Week 5: MDP Solving; Week 6: MDP Solving (continued)},
COMP4620/8620 lecture materials, Australian National University, 2026.

\bibitem{tutorials}
H. Kurniawati, \textit{Tutorials Weeks 6, 8 and 9}, COMP4620/8620,
Australian National University, 2026.

\bibitem{rl-lectures}
H. Kurniawati, \textit{Reinforcement Learning, Weeks 8--11},
COMP4620/8620 lecture materials, Australian National University, 2026.

\bibitem{provided-code}
RDLLab, \textit{MultiDroneUnc}, supplied code and README,
\url{https://github.com/RDLLab/MultiDroneUnc}.
Local revision \texttt{ea3cbfe}; full revision and source hashes are recorded
in \texttt{UPSTREAM.json}.
\end{thebibliography}

\end{document}
'''
    main_path.write_text(document)
    print('Completed Part B report inputs and verified release measurements.')


if __name__=='__main__':main()
