"""Summarize measured episodes and build report tables/figures.

The independent sampling unit is an episode within a scenario. Factorial
marginal effects use paired seed-block averages, not 180 pooled IID trials.
"""

from collections import defaultdict
import csv
import json
import math
import os
from pathlib import Path
import tempfile

os.environ.setdefault('MPLCONFIGDIR',str(Path(tempfile.gettempdir())/'comp8620-mpl'))
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
import numpy as np
from scipy import stats

ROOT=Path(__file__).resolve().parents[1]
REPORT=next((p for p in (ROOT/'report',ROOT.parent/'A2')
             if (p/'u8076655_A2_report.tex').exists()),ROOT/'report')
TABLES=REPORT/'tables'
FIGURES=REPORT/'figures'


def interval(values):
    values=np.asarray(list(values),dtype=float)
    mean=float(values.mean())
    half=float(stats.t.ppf(.975,len(values)-1)*values.std(ddof=1)/math.sqrt(len(values))) if len(values)>1 else 0.
    return dict(mean=mean,lower=mean-half,upper=mean+half,half=half,n=len(values))


def wilson(successes,n):
    z=stats.norm.ppf(.975);p=successes/n;d=1+z*z/n
    center=(p+z*z/(2*n))/d
    half=z*math.sqrt(p*(1-p)/n+z*z/(4*n*n))/d
    return dict(mean=p,lower=center-half,upper=center+half,n=n,successes=successes)


def read(suite,expected):
    with (ROOT/f'results/{suite}.csv').open() as f:
        rows=list(csv.DictReader(f))
    if len(rows)!=expected:
        raise ValueError(f'{suite}: expected {expected} episodes, found {len(rows)}; wait for the serial run to finish')
    seen=set()
    for row in rows:
        key=row['scenario'],row['variant'],float(row['planning_budget']),int(row['seed'])
        if key in seen:raise ValueError(f'Duplicate episode {key}')
        seen.add(key)
        row['success']=row['success']=='True'
        for k in ('seed','steps','simulations','generative_calls','num_actions','num_drones','obstacles'):
            row[k]=int(row[k])
        for k in ('penalized_steps','discounted_return','setup_seconds','planning_seconds','mean_plan_seconds',
                  'max_plan_seconds','planning_budget','mean_root_actions'):
            row[k]=float(row[k])
        for k in ('S','A','C'):
            if row[k]:row[k]=int(row[k])
    return rows


def summarize(rows):
    result={'success':wilson(sum(r['success'] for r in rows),len(rows)),
            'collisions':sum(r['termination']=='collision' for r in rows)}
    for name in ('penalized_steps','discounted_return','setup_seconds','mean_plan_seconds','simulations','mean_root_actions'):
        result[name]=interval(r[name] for r in rows)
    result['max_plan_seconds']=max(r['max_plan_seconds'] for r in rows)
    return result


def grouped(rows,fields):
    groups=defaultdict(list)
    for row in rows:groups[tuple(row[k] for k in fields)].append(row)
    return groups


def fmt(value,digits=1):
    return f"{value['mean']:.{digits}f} $\\pm$ {value['half']:.{digits}f}"


def latex_rows(path,rows):
    macros={'factorial_rows':'FactorialRows','factor_effect_rows':'FactorEffectRows',
            'ablation_rows':'AblationRows','budget_rows':'BudgetRows','regression_rows':'RegressionRows'}
    body='\n'.join(' & '.join(map(str,row))+r' \\' for row in rows)
    path.write_text('\\newcommand{\\'+macros[path.stem]+'}{%\n'+body+'\n}\n')


def main():
    TABLES.mkdir(parents=True,exist_ok=True);FIGURES.mkdir(parents=True,exist_ok=True)
    suites={name:read(name,n) for name,n in [('regression',360),('random',160),('factorial',540),('ablation',400),('budget',90)]}
    summary={}
    for suite,rows in suites.items():
        summary[suite]={}
        for key,group in grouped(rows,('scenario','variant','planning_budget')).items():
            summary[suite]['|'.join(map(str,key))]=summarize(group)

    factorial=suites['factorial']
    factor_groups=grouped(factorial,('S','A','C'))
    table=[]
    for key,rows in sorted(factor_groups.items()):
        s=summarize(rows)
        table.append([key[0],key[1]**2,key[2],f"{s['success']['successes']}/20",
                      fmt(s['penalized_steps']),fmt(s['discounted_return']),
                      fmt(interval(1000*r['mean_plan_seconds'] for r in rows),2)])
    latex_rows(TABLES/'factorial_rows.tex',table)

    effects={};marginals={}
    for factor,levels in [('S',[5,10,20]),('A',[6,18,26]),('C',[0,2,5])]:
        blocks={}
        marginals[factor]={}
        for level in levels:
            subset=[r for r in factorial if r[factor]==level]
            means={seed:np.mean([r['penalized_steps'] for r in subset if r['seed']==seed]) for seed in range(20)}
            blocks[level]=means
            marginals[factor][level]=interval(means.values())
        deltas=[blocks[levels[-1]][seed]-blocks[levels[0]][seed] for seed in range(20)]
        effects[factor]={**interval(deltas),'paired_deltas':list(map(float,deltas))}
    summary['factor_effects']=effects
    summary['factor_marginals']=marginals
    pairwise={}
    for first,second in [('C','S'),('C','A'),('A','S')]:
        pairwise[first+'-'+second]=interval(np.array(effects[first]['paired_deltas'])-effects[second]['paired_deltas'])
    summary['factor_pairwise']=pairwise
    latex_rows(TABLES/'factor_effect_rows.tex',[[{'S':'State size','A':'Action size','C':'Clutter'}[k],
                 f"{effects[k]['mean']:.1f}",f"[{effects[k]['lower']:.1f}, {effects[k]['upper']:.1f}]"] for k in ('S','A','C')])

    cases=['demo_open_2d','demo_four_3d','swap_2d','narrow_passage']
    variants=['full','no_guidance','no_leaf','no_widening','heuristic']
    names={'full':'Full','no_guidance':'Uniform actions','no_leaf':'Zero leaf value',
           'no_widening':'No widening','heuristic':'Guided only'}
    ablation_groups=grouped(suites['ablation'],('scenario','variant'))
    ablation_table=[]
    ablation_effects={}
    for variant in variants:
        cells=[names[variant]]
        for case in cases:
            s=summarize(ablation_groups[case,variant])
            cells.append(f"{s['success']['successes']}/20; {fmt(s['penalized_steps'])}")
        ablation_table.append(cells)
        if variant!='full':
            deltas=[]
            for seed in range(20):
                values=[]
                for case in cases:
                    other=next(r for r in ablation_groups[case,variant] if r['seed']==seed)
                    full=next(r for r in ablation_groups[case,'full'] if r['seed']==seed)
                    values.append(other['penalized_steps']-full['penalized_steps'])
                deltas.append(np.mean(values))
            ablation_effects[variant]=interval(deltas)
    summary['ablation_effects']=ablation_effects
    latex_rows(TABLES/'ablation_rows.tex',ablation_table)

    budget_table=[]
    short={'demo_open_2d':'Open 2D','demo_four_3d':'Four 3D','swap_2d':'Swap 2D'}
    for (case,budget),rows in sorted(grouped(suites['budget'],('scenario','planning_budget')).items()):
        s=summarize(rows)
        budget_table.append([short[case],f'{budget:g}',f"{s['success']['successes']}/10",
                             fmt(s['penalized_steps']),fmt(s['discounted_return']),f"{s['max_plan_seconds']:.3f}"])
    latex_rows(TABLES/'budget_rows.tex',budget_table)

    regression_table=[]
    for (case,),rows in grouped(suites['regression'],('scenario',)).items():
        s=summarize(rows)
        label=case.replace('_',r'\_')
        statuses={r['termination'] for r in rows}
        regression_table.append([r'\texttt{'+label+'}',f"{s['success']['successes']}/20",s['collisions'],
                                 fmt(s['penalized_steps']),f"{s['max_plan_seconds']:.4f}"])
    latex_rows(TABLES/'regression_rows.tex',regression_table)

    flat=[]
    for suite,entries in summary.items():
        if suite not in suites:continue
        for key,data in entries.items():
            record={'suite':suite,'case':key,'successes':data['success']['successes'],'n':data['success']['n'],
                    'success_mean':data['success']['mean'],'success_lower':data['success']['lower'],
                    'success_upper':data['success']['upper'],'collisions':data['collisions']}
            for metric in ('penalized_steps','discounted_return','setup_seconds','mean_plan_seconds','simulations','mean_root_actions'):
                for stat in ('mean','lower','upper'):record[metric+'_'+stat]=data[metric][stat]
            flat.append(record)
    with (ROOT/'results/summary.csv').open('w',newline='') as stream:
        writer=csv.DictWriter(stream,fieldnames=list(flat[0]));writer.writeheader();writer.writerows(flat)
    summary['total_episodes']=sum(map(len,suites.values()))
    summary['max_observed_plan_seconds']=max(r['max_plan_seconds'] for rows in suites.values() for r in rows)
    (ROOT/'results/summary.json').write_text(json.dumps(summary,indent=2)+'\n')

    plt.rcParams.update({'font.family':'serif','mathtext.fontset':'cm','font.size':9,
                         'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42})
    fig,axes=plt.subplots(1,3,figsize=(7,2.55),sharey=True,layout='constrained')
    for ax,factor,levels,title,color in zip(axes,['S','A','C'],[[5,10,20],[6,18,26],[0,2,5]],
                           ['State space','Action space','Clutter'],['#1F4E79','#3E7B60','#B65D47']):
        values=[marginals[factor][level] for level in levels]
        x=[v*v for v in levels] if factor=='A' else levels
        ax.errorbar(x,[v['mean'] for v in values],yerr=[v['half'] for v in values],color=color,
                    marker='o',linewidth=1.5,capsize=3)
        if factor=='A':ax.set_xscale('log')
        ax.set_xticks(x,[str(v) for v in x]);ax.set_title(title)
        ax.set_xlabel({'S':r'Grid height $n_y$','A':r'Joint actions $|A|$','C':'Obstacle cells'}[factor])
        ax.grid(axis='y',alpha=.2)
    axes[0].set_ylabel('Penalized completion steps')
    fig.savefig(FIGURES/'complexity_effects.pdf',bbox_inches='tight');fig.savefig(FIGURES/'complexity_effects.png',dpi=200,bbox_inches='tight');plt.close(fig)

    fig,ax=plt.subplots(figsize=(6.7,2.5),layout='constrained')
    y=np.arange(len(ablation_effects));values=list(ablation_effects.values())
    ax.barh(y,[v['mean'] for v in values],xerr=[v['half'] for v in values],
            color='#527A9B',capsize=3,height=.6)
    ax.set_yticks(y,[names[k] for k in ablation_effects]);ax.invert_yaxis()
    ax.axvline(0,color='#444444',linewidth=.8);ax.grid(axis='x',alpha=.2)
    ax.set_xlabel('Increase in penalized steps relative to full solver')
    fig.savefig(FIGURES/'ablation_effects.pdf',bbox_inches='tight');fig.savefig(FIGURES/'ablation_effects.png',dpi=200,bbox_inches='tight');plt.close(fig)
    print(json.dumps({'total_episodes':summary['total_episodes'],'effects':effects,
                      'ablation_effects':ablation_effects,'pairwise':pairwise},indent=2))


if __name__ == '__main__':main()
