"""Model semantics, interface compliance, and online-planning regressions."""

from copy import deepcopy
from pathlib import Path
from tempfile import TemporaryDirectory
import time
import unittest

import numpy as np
import yaml

from environment import ActionMask, HeadlessMultiDroneUnc
from planner import MCTSPlanner, action_vectors, decode_action, encode_action
from run_u8076655 import run_episode

ROOT = Path(__file__).resolve().parents[1]


def configuration(count=1, altitude=False):
    return dict(grid_size=[5,4,3 if altitude else 1], change_altitude=altitude,
                start_positions=[[1,i+1,0] for i in range(count)],
                goal_positions=[[4,i+1,0] for i in range(count)], obstacle_cells=[],
                step_cost=-1., collision_penalty=-100., goal_reward=100.,
                discount_factor=.98, max_num_steps=30, alpha=.5)


class FixedChoices:
    def __init__(self, choices):
        self.choices = iter(choices)

    def choice(self, count, p):
        chosen = next(self.choices)
        assert p[chosen] > 0
        return chosen


class PublicOnly:
    def __init__(self, env):
        object.__setattr__(self, '_wrapped', env)

    def get_config(self):
        return object.__getattribute__(self, '_wrapped').get_config()

    @property
    def num_actions(self):
        return object.__getattribute__(self, '_wrapped').num_actions

    def simulate(self, state, action):
        return object.__getattribute__(self, '_wrapped').simulate(state, action)

    def __getattr__(self, name):
        raise AssertionError(f'Planner accessed an unapproved simulator attribute: {name}')


class SolverTests(unittest.TestCase):
    def setUp(self):
        self.temp = TemporaryDirectory()
        self.addCleanup(self.temp.cleanup)
        self.path = Path(self.temp.name)/'case.yaml'

    def env(self, data=None, seed=0):
        self.path.write_text(yaml.safe_dump(data or configuration()))
        env = HeadlessMultiDroneUnc(self.path, seed=seed)
        state = env.reset()
        return env, state

    def test_encoding_matches_upstream(self):
        for altitude in (False,True):
            env, _ = self.env(configuration(2,altitude))
            base = 26 if altitude else 8
            for a in [0,1,base-1,base,base**2-1,base**2//2]:
                digits = decode_action(a,base,2)
                self.assertEqual(encode_action(digits,base),a)
                self.assertEqual(env._encode_action(np.array(digits)),a)
                np.testing.assert_array_equal(env._decode_action(a),digits)

    def test_negative_action_rejected(self):
        with self.assertRaises(ValueError):
            decode_action(-1,8,2)

    def test_terminal_bandit_selects_known_best_action(self):
        env,state=self.env()
        class TerminalBandit:
            def get_config(self):return env.get_config()
            num_actions=8
            def simulate(self,current,action):
                if current[:,3].all():raise AssertionError('Terminal state was simulated again')
                successor=current.copy();successor[0,:3]=[4,1,0];successor[0,3]=1
                return successor, (100. if action==6 else -100.), True, {}
        planner=MCTSPlanner(TerminalBandit(),max_simulations=128,guided=False)
        self.assertEqual(planner.plan(state,1.),6)
        self.assertEqual(planner.last_stats['simulations'],128)

    def test_discount_endpoints_and_map_fallback(self):
        for gamma in (0.,1.):
            data=configuration();data['discount_factor']=gamma
            env,state=self.env(data)
            planner=MCTSPlanner(env,max_simulations=5,max_map_cells=0)
            self.assertTrue(0 <= planner.plan(state,.2) < 8)
            self.assertTrue(np.isfinite(planner._leaf(state,10)))

    def test_invalid_budget(self):
        env,state=self.env();planner=MCTSPlanner(env)
        for budget in (-1.,float('nan'),float('inf')):
            with self.assertRaises(ValueError):planner.plan(state,budget)

    def test_boundary_slips_renormalize_without_staying(self):
        data=configuration();data['start_positions']=[[0,0,0]]
        env,state=self.env(data)
        samples=[env.simulate(state,0)[0][0,:3] for _ in range(200)]
        self.assertTrue(all(tuple(p) in {(0,1,0),(1,0,0),(1,1,0)} for p in samples))

    def test_obstacle_collision_and_reward(self):
        data=configuration();data['obstacle_cells']=[[2,1,0]]
        env,state=self.env(data);env.rng=FixedChoices([6])
        next_state,reward,done,info=env.simulate(state,6)
        np.testing.assert_array_equal(next_state[0,:3],state[0,:3])
        self.assertEqual(reward,-101.)
        self.assertTrue(done);self.assertEqual(info['num_collisions'],1)

    def test_same_cell_collision_counts_both_drones(self):
        data=configuration(2);data['start_positions']=[[1,1,0],[3,1,0]]
        env,state=self.env(data);env.rng=FixedChoices([6,1])
        _,reward,done,info=env.simulate(state,encode_action([6,1],8))
        self.assertTrue(done);self.assertEqual(info['num_vehicle_collisions'],2)
        self.assertEqual(reward,-202.)

    def test_cell_swap_is_permitted_by_supplied_model(self):
        data=configuration(2);data['start_positions']=[[1,1,0],[2,1,0]]
        env,state=self.env(data);env.rng=FixedChoices([6,1])
        successor,_,done,info=env.simulate(state,encode_action([6,1],8))
        np.testing.assert_array_equal(successor[:,:3],[[2,1,0],[1,1,0]])
        self.assertFalse(done);self.assertEqual(info['num_vehicle_collisions'],0)

    def test_reached_drone_is_frozen_and_solid(self):
        data=configuration(2);data['start_positions']=[[2,1,0],[1,1,0]]
        data['goal_positions']=[[2,1,0],[4,2,0]]
        env,state=self.env(data);env.rng=FixedChoices([6,6])
        successor,_,done,info=env.simulate(state,encode_action([0,6],8))
        np.testing.assert_array_equal(successor[0],[2,1,0,1])
        self.assertTrue(done);self.assertEqual(info['num_vehicle_collisions'],2)

    def test_goal_reward_is_paid_only_on_first_arrival(self):
        data=configuration(2);data['start_positions']=[[1,1,0],[1,3,0]]
        data['goal_positions']=[[2,1,0],[4,3,0]]
        env,state=self.env(data);env.rng=FixedChoices([6,6])
        state,reward,done,_=env.simulate(state,encode_action([6,6],8))
        self.assertFalse(done);self.assertEqual(reward,98.)
        env.rng=FixedChoices([6,1])
        _,reward,done,_=env.simulate(state,encode_action([0,1],8))
        self.assertFalse(done);self.assertEqual(reward,-2.)

    def test_simulate_has_no_physical_state_side_effects(self):
        env,state=self.env();before=state.copy();positions=env.positions.copy()
        for _ in range(30):env.simulate(state,6)
        np.testing.assert_array_equal(state,before)
        np.testing.assert_array_equal(env.positions,positions)
        self.assertEqual(env.t,0)

    def test_altitude_is_fixed_in_2d(self):
        env,state=self.env(configuration(2))
        for a in range(64):
            next_state,_,_,_=env.simulate(state,a)
            np.testing.assert_array_equal(next_state[:,2],state[:,2])

    def test_empirical_probability_matches_interior_model(self):
        data=configuration();data['start_positions']=[[2,2,0]]
        data['obstacle_cells']=[[3,2,0]]
        env,state=self.env(data)
        collisions=sum(env.simulate(state,6)[3]['num_collisions'] for _ in range(5000))
        self.assertLess(abs(collisions/5000-2/3),.03)

    def test_action_mask_preserves_retained_transition_laws(self):
        data=configuration(2,True)
        first,state=self.env(data,seed=12);second,_=self.env(data,seed=12)
        masked=ActionMask(first,'axial')
        self.assertEqual(masked.num_actions,36)
        for action in range(36):
            x,r,d,info=masked.simulate(state,action)
            y,s,e,j=second.simulate(state,masked.map_action(action))
            np.testing.assert_array_equal(x,y)
            self.assertEqual((r,d,info),(s,e,j))

    def test_planner_uses_only_public_interfaces(self):
        env,state=self.env(configuration(2,True))
        planner=MCTSPlanner(PublicOnly(env),max_simulations=8)
        action=planner.plan(state,.2)
        self.assertTrue(0 <= action < 26**2)
        self.assertEqual(planner.last_stats['simulations'],8)

    def test_zero_budget_returns_valid_fallback_without_sampling(self):
        env,state=self.env(configuration(2,True));planner=MCTSPlanner(env)
        action=planner.plan(state,0)
        self.assertTrue(0 <= action < env.num_actions)
        self.assertEqual(planner.last_stats['generative_calls'],0)

    def test_time_budget_on_four_drone_space(self):
        data=yaml.safe_load((ROOT/'environments/demo_four_3d.yaml').read_text())
        env,state=self.env(data);planner=MCTSPlanner(env)
        start=time.perf_counter();action=planner.plan(state,.05);elapsed=time.perf_counter()-start
        self.assertTrue(0 <= action < 26**4)
        self.assertLess(elapsed,.075)

    def test_terminal_input_does_not_sample(self):
        data=configuration();data['goal_positions']=data['start_positions']
        env,state=self.env(data);planner=MCTSPlanner(env)
        planner.plan(state,.1)
        self.assertEqual(planner.last_stats['generative_calls'],0)

    def test_one_remaining_step_does_not_roll_past_time_limit(self):
        data=configuration();data['max_num_steps']=1
        env,state=self.env(data);planner=MCTSPlanner(env,max_simulations=8)
        planner.plan(state,.2)
        self.assertEqual(planner.last_stats['generative_calls'],8)
        planner.plan(state,.2)
        self.assertEqual(planner.last_stats['generative_calls'],0)

    def test_initial_success_and_static_infeasibility(self):
        for name,success,status in [('single_cell_goal',True,'success'),
                                    ('already_at_goals',True,'success'),
                                    ('infeasible_altitude',False,'infeasible_static_path'),
                                    ('infeasible_wall',False,'infeasible_static_path'),
                                    ('infeasible_shared_goal',False,'infeasible_shared_goals')]:
            with self.subTest(name=name):
                result=run_episode(ROOT/f'environments/{name}.yaml',planning_time=.01)
                self.assertEqual(result['success'],success)
                self.assertEqual(result['termination'],status)
                self.assertEqual(result['steps'],0)

    def test_fixed_iteration_reproducibility(self):
        results=[run_episode(ROOT/'environments/demo_open_2d.yaml',seed=13,planning_time=1.,
                             planner_options={'max_simulations':8}) for _ in range(2)]
        self.assertEqual(results[0]['trajectory'],results[1]['trajectory'])

    def test_yaml_seed_is_used_unless_explicitly_overridden(self):
        data=configuration();data['seed']=37
        self.path.write_text(yaml.safe_dump(data))
        default=run_episode(self.path,planning_time=0,variant='heuristic')
        explicit=run_episode(self.path,seed=37,planning_time=0,variant='heuristic')
        override=run_episode(self.path,seed=11,planning_time=0,variant='heuristic')
        self.assertEqual(default['seed'],37)
        self.assertEqual(default['trajectory'],explicit['trajectory'])
        self.assertEqual(override['seed'],11)

    def test_execution_randomness_is_independent_of_search(self):
        first,state=self.env(seed=4);second,_=self.env(seed=4);model,_=self.env(seed=1004)
        for _ in range(100):model.simulate(state,6)
        x,r,d,i=first.step(6);y,s,e,j=second.step(6)
        np.testing.assert_array_equal(x,y);self.assertEqual((r,d,i),(s,e,j))

    def test_invalid_configurations_fail_clearly(self):
        changes=[{'alpha':0.}, {'alpha':-1.}, {'discount_factor':1.1}, {'max_num_steps':0},
                 {'grid_size':[0,4,1]}, {'start_positions':[[8,0,0]]},
                 {'goal_positions':[[1.5,0,0]]}, {'obstacle_cells':[[4,0,0]]},
                 {'obstacle_cells':[[1,1,0]]}]
        for change in changes:
            with self.subTest(change=change):
                data=configuration();data.update(change)
                with self.assertRaises(ValueError):self.env(data)


if __name__ == '__main__':
    unittest.main()
